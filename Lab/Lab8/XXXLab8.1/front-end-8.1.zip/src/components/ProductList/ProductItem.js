const ProductItem = (props) => {
  const { product } = props;
  const addToCartHandler = (event) => {
    event.preventDefault();
    console.log(product);
    fetch("http://localhost:5000/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: product.id, price: product.price }),
    });
  };
  return (
    <form className="product-form" onSubmit={addToCartHandler}>
      <div className="card">
        <div className="product-item">
          <div className="card__header">
            <h1 className="product__title">{product.title}</h1>
          </div>
          <div className="card__content">
            <div className="card__image">
              <img src={product.imageUrl}></img>
            </div>
            <h1 className="product__price">${product.price}</h1>
            <p className="product__description">{product.description}</p>
          </div>
        </div>
        <div className="card__actions">
          <button className="btn" type="submit">
            Add to cart
          </button>
        </div>
      </div>
    </form>
  );
};

export default ProductItem;
