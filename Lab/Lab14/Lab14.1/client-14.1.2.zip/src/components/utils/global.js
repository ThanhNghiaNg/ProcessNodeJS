export const serverURL = "http://localhost:5000";
export let refresh = false;
export const setRefresh = () => {
  refresh = !refresh;
};
