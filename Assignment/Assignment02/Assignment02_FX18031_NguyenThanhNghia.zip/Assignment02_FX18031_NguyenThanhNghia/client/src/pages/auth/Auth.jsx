import AuthForm from "../../components/AuthForm/AuthForm";

const Auth = (props) => {
  return <AuthForm login={props.login} />;
};

export default Auth;
