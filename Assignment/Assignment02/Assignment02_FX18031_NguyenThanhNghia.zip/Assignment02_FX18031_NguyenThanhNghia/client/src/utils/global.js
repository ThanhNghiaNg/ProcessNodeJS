export const serverURL = "http://localhost:5000";
