import React from "react";
import LiveChat from "../components/LiveChat/LiveChat";

function Chat(props) {
  return (
    <div>
      <LiveChat />
    </div>
  );
}

export default Chat;
