export const hostURL = 'http://localhost:5000'
export const USER_TOKEN01 = '8qlOkxz4wq'
export const USER_TOKEN02 = 'RYoOcWM4JW'